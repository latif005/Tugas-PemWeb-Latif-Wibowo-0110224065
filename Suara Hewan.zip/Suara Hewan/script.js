function playSound(animal) {
    let sound;
    switch (animal) {
        case "kucing":
            sound = new Audio('sounds/kucing.mp3');
            break;
        case "anjing":
            sound = new Audio('sounds/anjing.mp3');
            break;
        case "sapi":
            sound = new Audio('sounds/sapi.mp3');
            break;
        case "monyet":
            sound = new Audio('sounds/monyet.mp3');
            break;
        case "harimau":
            sound = new Audio('sounds/harimau.mp3');
            break;
        default:
            console.log("Hewan tidak dikenal");
            return;
    }
    sound.play();
            
}